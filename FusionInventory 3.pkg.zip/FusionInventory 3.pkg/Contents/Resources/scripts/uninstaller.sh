#!/bin/bash

FILES="/opt/fusioninventory-agent /var/log/fusioninventory.log"
FILES="$FILES /usr/local/bin/dmidecode"
FILES="$FILES /Library/LaunchDaemons/org.fusioninventory.agent.plist"

echo 'Stopping and unloading service'
sudo launchctl stop org.fusioninventory.agent
sudo launchctl unload /Library/LaunchDaemons/org.fusioninventory.agent.plist

# Still wait until process has been stopped
read PID XXX <<<`ps -ec -o pid,command | grep fusioninventory-agent`
if [ "$PID" !=  "" ]; then
    let TIMEOUT=300
    while sudo kill -0 $PID 2>/dev/null
    do
        sleep .1
        (( --TIMEOUT )) || break
    done
    if [ "$TIMEOUT" == "0" ]; then
        echo "killing process: $PID"
        sudo kill $PID
    fi
fi

echo 'Saving current file etc/agent.cfg if exists'
CONFIGPATH="/opt/fusioninventory-agent"
if [ -f "$CONFIGPATH/etc/agent.cfg" ]; then
    cp -af "$CONFIGPATH/etc/agent.cfg" /tmp/fusioninventory-agent.cfg
fi
if [ -d "$CONFIGPATH/etc/conf.d" ]; then
    cp -af "$CONFIGPATH/etc/conf.d" /tmp
fi

for FILE in $FILES; do
  echo "removing '$FILE'"
  rm -f -R "$FILE"
done
